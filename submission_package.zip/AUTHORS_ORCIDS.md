# Authors, Affiliations, ORCIDs (to paste into journal portal)

- Author 1
  - Name: [First Last]
  - Affiliation: [Department, Institution, City, Country]
  - ORCID: [0000-0000-0000-0000]
  - Email: [email]
  - Role: [Conceptualization, Methodology, Software, Writing]

- Author 2
  - Name: [First Last]
  - Affiliation: [Department, Institution, City, Country]
  - ORCID: [0000-0000-0000-0000]
  - Email: [email]
  - Role: [Investigation, Validation, Writing]

- Corresponding Author
  - Name: [First Last]
  - Affiliation: [Department, Institution, City, Country]
  - Email: [email]
  - Address: [Postal address]

## Portal Paste (example)
"Authors: [Name, ORCID, Affiliation]; Corresponding: [Name, Email, Address]."
